var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/engine/KeystrokeTracker.ts
var KeystrokeTracker = class {
  constructor(windowDurationMs = 8e3) {
    __publicField(this, "events", []);
    __publicField(this, "lastTimestamp", null);
    __publicField(this, "windowDurationMs");
    __publicField(this, "onMetricsUpdate", null);
    __publicField(this, "handleKeyDown", (e) => {
      const now = Date.now();
      let category = "OTHER";
      if (e.key === "Backspace" || e.key === "Delete") {
        category = "BACKSPACE";
      } else if (e.key.length === 1 && !e.ctrlKey && !e.altKey && !e.metaKey) {
        category = "PRINTABLE";
      }
      const interKeyInterval = this.lastTimestamp !== null ? Math.max(0, now - this.lastTimestamp) : 0;
      this.lastTimestamp = now;
      const event = {
        timestamp: now,
        interKeyInterval,
        category
      };
      this.pushEvent(event);
    });
    this.windowDurationMs = windowDurationMs;
  }
  pushEvent(event) {
    this.lastTimestamp = event.timestamp;
    this.events.push(event);
    this.pruneOldEvents(event.timestamp);
    if (this.onMetricsUpdate) {
      this.onMetricsUpdate([...this.events]);
    }
  }
  pruneOldEvents(now = Date.now()) {
    const cutoff = now - this.windowDurationMs;
    this.events = this.events.filter((e) => e.timestamp >= cutoff);
  }
  getEvents() {
    this.pruneOldEvents();
    return [...this.events];
  }
  getLastKeyTimestamp() {
    return this.lastTimestamp;
  }
  reset() {
    this.events = [];
    this.lastTimestamp = null;
  }
  setUpdateCallback(callback) {
    this.onMetricsUpdate = callback;
  }
};

// src/engine/MetricsCalculator.ts
var MetricsCalculator = class {
  static calculate(events, lastKeyTimestamp, windowMs = 8e3) {
    const now = Date.now();
    const idleMs = lastKeyTimestamp ? Math.max(0, now - lastKeyTimestamp) : Infinity;
    const idleSeconds = idleMs === Infinity ? 999 : idleMs / 1e3;
    if (events.length === 0) {
      return {
        wpm: 0,
        ikiMean: 0,
        ikiVariance: 0,
        backspaceCount: 0,
        backspaceRatio: 0,
        burstCount: 0,
        idleSeconds,
        totalKeysInWindow: 0
      };
    }
    const totalKeysInWindow = events.length;
    const windowSeconds = Math.min(windowMs / 1e3, Math.max(1, (now - events[0].timestamp) / 1e3));
    const estimatedWords = totalKeysInWindow / 5;
    const minutes = windowSeconds / 60;
    const wpm = Math.round(estimatedWords / minutes);
    const validIntervals = events.map((e) => e.interKeyInterval).filter((iki) => iki > 0 && iki < 2e3);
    let ikiMean = 0;
    let ikiVariance = 0;
    if (validIntervals.length > 0) {
      const sum = validIntervals.reduce((acc, val) => acc + val, 0);
      ikiMean = sum / validIntervals.length;
      const squaredDiffs = validIntervals.map((val) => Math.pow(val - ikiMean, 2));
      const avgSquaredDiff = squaredDiffs.reduce((acc, val) => acc + val, 0) / validIntervals.length;
      ikiVariance = Math.sqrt(avgSquaredDiff);
    }
    const backspaceCount = events.filter((e) => e.category === "BACKSPACE").length;
    const backspaceRatio = totalKeysInWindow > 0 ? backspaceCount / totalKeysInWindow : 0;
    const burstCount = validIntervals.filter((iki) => iki < 130).length;
    return {
      wpm,
      ikiMean: Math.round(ikiMean),
      ikiVariance: Math.round(ikiVariance),
      backspaceCount,
      backspaceRatio,
      burstCount,
      idleSeconds,
      totalKeysInWindow
    };
  }
};

// src/engine/MoodClassifier.ts
var MoodClassifier = class {
  constructor() {
    __publicField(this, "currentMood", "IDLE");
    __publicField(this, "history", []);
    __publicField(this, "calmDurationMs", 0);
    __publicField(this, "lastEvaluationTime", Date.now());
  }
  /**
   * Classify candidate mood state based on rolling metrics and thresholds
   */
  classifyRaw(metrics, sensitivity = "medium") {
    const sensitivityMultiplier = sensitivity === "high" ? 0.8 : sensitivity === "low" ? 1.2 : 1;
    if (metrics.idleSeconds > 15 || metrics.totalKeysInWindow < 3) {
      return "IDLE";
    }
    const rageWpmThreshold = 50 * sensitivityMultiplier;
    const rageBurstThreshold = 3 * sensitivityMultiplier;
    const highBackspaceRatio = 0.2 / sensitivityMultiplier;
    const highVarianceThreshold = 140 / sensitivityMultiplier;
    const lowVarianceThreshold = 95 * sensitivityMultiplier;
    const isFastTyping = metrics.wpm >= rageWpmThreshold || metrics.burstCount >= rageBurstThreshold || metrics.ikiMean > 0 && metrics.ikiMean <= 140 * sensitivityMultiplier;
    const isHeavyBackspace = metrics.backspaceRatio >= highBackspaceRatio || metrics.backspaceCount >= 3;
    if (isFastTyping || isHeavyBackspace) {
      return "RAGE";
    }
    if (metrics.ikiVariance >= highVarianceThreshold || metrics.backspaceRatio >= highBackspaceRatio) {
      return "ERRATIC";
    }
    if (metrics.ikiVariance <= lowVarianceThreshold && metrics.backspaceRatio < 0.15 && metrics.wpm >= 15) {
      return "CALM";
    }
    return "CALM";
  }
  /**
   * Apply hysteresis / smoothing buffer to avoid state flickering
   */
  update(metrics, sensitivity = "medium") {
    const now = Date.now();
    const deltaMs = now - this.lastEvaluationTime;
    this.lastEvaluationTime = now;
    const rawCandidate = this.classifyRaw(metrics, sensitivity);
    this.history.push(rawCandidate);
    if (this.history.length > 3) {
      this.history.shift();
    }
    const recentMatches = this.history.filter((m) => m === rawCandidate).length;
    let nextState = this.currentMood;
    if (recentMatches >= 2 || rawCandidate === "IDLE" || rawCandidate === "RAGE") {
      nextState = rawCandidate;
    }
    if ((this.currentMood === "RAGE" || this.currentMood === "ERRATIC") && nextState === "CALM") {
      nextState = "RECOVERING";
    }
    if (nextState === "CALM" || nextState === "RECOVERING") {
      this.calmDurationMs += deltaMs;
    } else {
      this.calmDurationMs = 0;
    }
    this.currentMood = nextState;
    return this.currentMood;
  }
  getCalmDurationMs() {
    return this.calmDurationMs;
  }
  getCurrentMood() {
    return this.currentMood;
  }
  reset() {
    this.currentMood = "IDLE";
    this.history = [];
    this.calmDurationMs = 0;
    this.lastEvaluationTime = Date.now();
  }
};

// src/engine/StorageService.ts
var SETTINGS_KEY = "typemood_user_settings_v1";
var HISTORY_KEY = "typemood_daily_history_v1";
var DEFAULT_SETTINGS = {
  notificationsEnabled: true,
  soundEnabled: true,
  darkTheme: true,
  theme: "default",
  sensitivity: "medium",
  currentSpecies: "FERN",
  unlockedSpecies: ["FERN"]
};
var StorageService = class {
  static getSettings() {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      if (data) {
        return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
      }
    } catch (e) {
      console.warn("Failed to parse settings from LocalStorage", e);
    }
    return DEFAULT_SETTINGS;
  }
  static saveSettings(settings) {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (e) {
      console.error("Failed to save settings", e);
    }
  }
  static getTodayDateString() {
    const d = /* @__PURE__ */ new Date();
    return d.toISOString().split("T")[0];
  }
  static getHistory() {
    try {
      const data = localStorage.getItem(HISTORY_KEY);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.warn("Failed to parse history from LocalStorage", e);
    }
    return this.generateDefaultSampleHistory();
  }
  static saveHistory(history) {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    } catch (e) {
      console.error("Failed to save history", e);
    }
  }
  /**
   * Log a real-time mood tick (e.g. every 2 seconds) to accumulate stats for today
   */
  static recordMoodTick(mood, keystrokesInTick, currentWpm) {
    const today = this.getTodayDateString();
    const history = this.getHistory();
    const record = history[today] || {
      date: today,
      dominantMood: "CALM",
      healthScore: 85,
      totalKeystrokes: 0,
      wpmAverage: 0,
      moodDistribution: {
        CALM: 0,
        ERRATIC: 0,
        RAGE: 0,
        IDLE: 0,
        RECOVERING: 0
      }
    };
    record.totalKeystrokes += keystrokesInTick;
    if (currentWpm > 0) {
      record.wpmAverage = record.wpmAverage === 0 ? currentWpm : Math.round(record.wpmAverage * 0.9 + currentWpm * 0.1);
    }
    const dist = record.moodDistribution;
    dist[mood] = (dist[mood] || 0) + 1;
    let maxVal = -1;
    let dominant = "CALM";
    Object.entries(dist).forEach(([m, count]) => {
      if (count > maxVal && m !== "IDLE") {
        maxVal = count;
        dominant = m;
      }
    });
    record.dominantMood = dominant;
    const totalTicks = Object.values(dist).reduce((a, b) => a + b, 0);
    if (totalTicks > 0) {
      const calmPercent = (dist.CALM + dist.RECOVERING) / totalTicks * 100;
      const ragePercent = dist.RAGE / totalTicks * 100;
      const erraticPercent = dist.ERRATIC / totalTicks * 100;
      const health = Math.max(10, Math.min(100, Math.round(calmPercent + 20 - ragePercent * 1.5 - erraticPercent * 0.8)));
      record.healthScore = health;
    }
    history[today] = record;
    this.saveHistory(history);
    this.checkPlantEvolution(history);
  }
  static checkPlantEvolution(history) {
    const settings = this.getSettings();
    const records = Object.values(history);
    if (records.length < 1) return;
    let unlockedNew = false;
    const newUnlocked = [...settings.unlockedSpecies];
    const avgHealth = records.reduce((acc, r) => acc + r.healthScore, 0) / records.length;
    if (avgHealth >= 75 && !newUnlocked.includes("BONSAI")) {
      newUnlocked.push("BONSAI");
      unlockedNew = true;
    }
    const totalKeystrokes = records.reduce((acc, r) => acc + r.totalKeystrokes, 0);
    if (totalKeystrokes > 2e3 && !newUnlocked.includes("CACTUS")) {
      newUnlocked.push("CACTUS");
      unlockedNew = true;
    }
    if (totalKeystrokes > 5e3 && avgHealth >= 80 && !newUnlocked.includes("GOLDEN_BLOSSOM")) {
      newUnlocked.push("GOLDEN_BLOSSOM");
      unlockedNew = true;
    }
    if (unlockedNew) {
      settings.unlockedSpecies = newUnlocked;
      this.saveSettings(settings);
    }
  }
  static generateDefaultSampleHistory() {
    const history = {};
    const today = /* @__PURE__ */ new Date();
    const moods = ["CALM", "CALM", "ERRATIC", "CALM", "RAGE", "CALM", "RECOVERING"];
    for (let i = 29; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().split("T")[0];
      const dominant = moods[i % moods.length];
      const healthScore = dominant === "CALM" ? Math.floor(75 + Math.random() * 20) : dominant === "ERRATIC" ? Math.floor(45 + Math.random() * 25) : dominant === "RAGE" ? Math.floor(25 + Math.random() * 20) : 80;
      history[dateStr] = {
        date: dateStr,
        dominantMood: dominant,
        healthScore,
        totalKeystrokes: Math.floor(400 + Math.random() * 1200),
        wpmAverage: Math.floor(45 + Math.random() * 35),
        moodDistribution: {
          CALM: dominant === "CALM" ? 65 : 25,
          ERRATIC: dominant === "ERRATIC" ? 55 : 20,
          RAGE: dominant === "RAGE" ? 60 : 10,
          IDLE: 15,
          RECOVERING: 15
        }
      };
    }
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
    return history;
  }
};

// src/extension/ExtensionStorage.ts
var DEFAULT_EXT_STATE = {
  currentMood: "IDLE",
  metrics: {
    wpm: 0,
    ikiMean: 0,
    ikiVariance: 0,
    backspaceCount: 0,
    backspaceRatio: 0,
    burstCount: 0,
    idleSeconds: 999,
    totalKeysInWindow: 0
  },
  calmDurationMs: 0,
  settings: {
    notificationsEnabled: true,
    soundEnabled: true,
    darkTheme: true,
    theme: "default",
    sensitivity: "medium",
    currentSpecies: "FERN",
    unlockedSpecies: ["FERN"]
  },
  history: {},
  floatingWidgetEnabled: true
};
var ExtensionStorage = class {
  static async getState() {
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.get(["typemood_ext_state"], (result) => {
          if (result && result.typemood_ext_state) {
            resolve({ ...DEFAULT_EXT_STATE, ...result.typemood_ext_state });
          } else {
            resolve(DEFAULT_EXT_STATE);
          }
        });
      });
    } else {
      const data = localStorage.getItem("typemood_ext_state");
      return data ? { ...DEFAULT_EXT_STATE, ...JSON.parse(data) } : DEFAULT_EXT_STATE;
    }
  }
  static async setState(partial) {
    const current = await this.getState();
    const updated = { ...current, ...partial };
    if (typeof chrome !== "undefined" && chrome.storage && chrome.storage.local) {
      return new Promise((resolve) => {
        chrome.storage.local.set({ typemood_ext_state: updated }, () => resolve());
      });
    } else {
      localStorage.setItem("typemood_ext_state", JSON.stringify(updated));
    }
  }
};

// src/extension/background.ts
var tracker = new KeystrokeTracker(8e3);
var classifier = new MoodClassifier();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "TYPEMOOD_KEYSTROKE" && message.payload) {
    const event = message.payload;
    tracker.pushEvent(event);
    sendResponse({ status: "ok" });
  } else if (message.type === "OPEN_SIDEPANEL") {
    if (chrome.sidePanel && chrome.sidePanel.open && _sender.tab?.windowId) {
      chrome.sidePanel.open({ windowId: _sender.tab.windowId });
    }
  }
  return true;
});
setInterval(async () => {
  const events = tracker.getEvents();
  const lastTs = tracker.getLastKeyTimestamp();
  const metrics = MetricsCalculator.calculate(events, lastTs, 8e3);
  const state = await ExtensionStorage.getState();
  const nextMood = classifier.update(metrics, state.settings.sensitivity);
  const calmMs = classifier.getCalmDurationMs();
  await ExtensionStorage.setState({
    currentMood: nextMood,
    metrics,
    calmDurationMs: calmMs
  });
  if (metrics.totalKeysInWindow > 0 || nextMood !== "IDLE") {
    StorageService.recordMoodTick(nextMood, events.length > 0 ? 1 : 0, metrics.wpm);
  }
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, {
          type: "MOOD_UPDATE",
          mood: nextMood,
          metrics
        }).catch(() => {
        });
      }
    });
  });
}, 800);
console.log("TypeMood Extension Service Worker Running!");
